package com.combatborder;

import com.combatborder.managers.CombatManager;
import com.combatborder.managers.WallManager;
import com.combatborder.managers.ZoneManager;
import com.combatborder.listeners.CombatListener;
import com.combatborder.listeners.MoveListener;
import com.combatborder.listeners.PearlListener;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class CombatBorder extends JavaPlugin {

    private CombatManager combatManager;
    private WallManager wallManager;
    private ZoneManager zoneManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.zoneManager = new ZoneManager(this);
        this.combatManager = new CombatManager(this);
        this.wallManager = new WallManager(this);

        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new MoveListener(this), this);
        getServer().getPluginManager().registerEvents(new PearlListener(this), this);

        getLogger().info("CombatBorder enabled! Safe zone protection active.");
    }

    @Override
    public void onDisable() {
        if (wallManager != null) wallManager.removeAllWalls();
        if (combatManager != null) combatManager.cleanup();
        getLogger().info("CombatBorder disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("combatborder.admin")) {
            sender.sendMessage(colorize("&cNo permission!"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(colorize("&6&lCombatBorder &7v1.0.0"));
            sender.sendMessage(colorize("&e/cb reload &7- Reload config"));
            sender.sendMessage(colorize("&e/cb info &7- Plugin info"));
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            zoneManager.reload();
            sender.sendMessage(colorize("&aCombatBorder config reloaded!"));
        } else if (args[0].equalsIgnoreCase("info")) {
            sender.sendMessage(colorize("&6Players in combat: &e" + combatManager.getCombatCount()));
            sender.sendMessage(colorize("&6Active walls: &e" + wallManager.getWallCount()));
        }
        return true;
    }

    public static String colorize(String msg) {
        return ChatColor.translateAlternateColorCodes('&', msg);
    }

    public CombatManager getCombatManager() { return combatManager; }
    public WallManager getWallManager() { return wallManager; }
    public ZoneManager getZoneManager() { return zoneManager; }
}
