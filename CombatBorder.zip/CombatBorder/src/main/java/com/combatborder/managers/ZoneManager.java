package com.combatborder.managers;

import com.combatborder.CombatBorder;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.List;

public class ZoneManager {

    private final CombatBorder plugin;
    private boolean worldGuardEnabled = false;

    // Manual safe zones [world, x1, y1, z1, x2, y2, z2]
    private final List<double[]> manualZones = new ArrayList<>();

    public ZoneManager(CombatBorder plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        manualZones.clear();

        // Check WorldGuard
        if (Bukkit.getPluginManager().getPlugin("WorldGuard") != null) {
            worldGuardEnabled = true;
            plugin.getLogger().info("WorldGuard detected! Using WorldGuard regions for safe zones.");
        } else {
            plugin.getLogger().info("WorldGuard not found. Using manual safe zones from config.");
        }

        // Load manual zones from config
        List<String> zones = plugin.getConfig().getStringList("safe-zones");
        for (String zone : zones) {
            String[] parts = zone.split(":");
            if (parts.length == 7) {
                try {
                    World world = Bukkit.getWorld(parts[0]);
                    if (world != null) {
                        manualZones.add(new double[]{
                            world.hashCode(),
                            Double.parseDouble(parts[1]),
                            Double.parseDouble(parts[2]),
                            Double.parseDouble(parts[3]),
                            Double.parseDouble(parts[4]),
                            Double.parseDouble(parts[5]),
                            Double.parseDouble(parts[6])
                        });
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    /**
     * Returns true if the given location is inside a safe/no-pvp zone.
     */
    public boolean isSafeZone(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;

        // Check WorldGuard first
        if (worldGuardEnabled && plugin.getConfig().getBoolean("worldguard-safe-flags", true)) {
            try {
                RegionContainer container = WorldGuard.getInstance().getPlatform().getRegionContainer();
                RegionQuery query = container.createQuery();
                com.sk89q.worldedit.util.Location wgLoc = BukkitAdapter.adapt(loc);

                // Check if pvp is denied at this location
                com.sk89q.worldguard.LocalPlayer localPlayer = null;
                boolean pvpAllowed = query.testState(wgLoc, localPlayer, Flags.PVP);
                if (!pvpAllowed) return true;
            } catch (Exception e) {
                // WorldGuard check failed, fall through to manual zones
            }
        }

        // Check manual zones
        for (double[] zone : manualZones) {
            if (loc.getWorld().hashCode() == (int) zone[0]) {
                double minX = Math.min(zone[1], zone[4]);
                double maxX = Math.max(zone[1], zone[4]);
                double minY = Math.min(zone[2], zone[5]);
                double maxY = Math.max(zone[2], zone[5]);
                double minZ = Math.min(zone[3], zone[6]);
                double maxZ = Math.max(zone[3], zone[6]);

                if (loc.getX() >= minX && loc.getX() <= maxX &&
                    loc.getY() >= minY && loc.getY() <= maxY &&
                    loc.getZ() >= minZ && loc.getZ() <= maxZ) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Find the nearest safe zone border location from a given position.
     * Returns null if not near any safe zone.
     */
    public Location getNearestBorder(Location loc, int searchRadius) {
        if (loc == null) return null;

        World world = loc.getWorld();
        int px = loc.getBlockX();
        int py = loc.getBlockY();
        int pz = loc.getBlockZ();

        // Scan in directions to find where safe zone starts
        for (int r = 1; r <= searchRadius; r++) {
            // Check in 4 directions
            Location[] checks = {
                new Location(world, px + r, py, pz),
                new Location(world, px - r, py, pz),
                new Location(world, px, py, pz + r),
                new Location(world, px, py, pz - r)
            };

            for (Location check : checks) {
                if (isSafeZone(check)) {
                    return check;
                }
            }
        }

        return null;
    }

    public boolean isWorldGuardEnabled() {
        return worldGuardEnabled;
    }
}
