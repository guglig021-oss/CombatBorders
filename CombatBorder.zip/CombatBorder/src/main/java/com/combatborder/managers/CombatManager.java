package com.combatborder.managers;

import com.combatborder.CombatBorder;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CombatManager {

    private final CombatBorder plugin;
    private final Map<UUID, BukkitTask> combatTasks = new HashMap<>();
    private final Map<UUID, Long> combatTime = new HashMap<>();

    public CombatManager(CombatBorder plugin) {
        this.plugin = plugin;
    }

    public void tag(Player player) {
        if (player.hasPermission("combatborder.bypass")) return;

        int duration = plugin.getConfig().getInt("combat-duration", 15);

        if (combatTasks.containsKey(player.getUniqueId())) {
            combatTasks.get(player.getUniqueId()).cancel();
        }

        combatTime.put(player.getUniqueId(), System.currentTimeMillis());

        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            untag(player.getUniqueId());
        }, duration * 20L);

        combatTasks.put(player.getUniqueId(), task);
    }

    public void untag(UUID uuid) {
        combatTime.remove(uuid);
        if (combatTasks.containsKey(uuid)) {
            combatTasks.get(uuid).cancel();
            combatTasks.remove(uuid);
        }
        // Remove wall when leaving combat
        Player p = Bukkit.getPlayer(uuid);
        if (p != null) {
            plugin.getWallManager().removeWall(p);
        }
    }

    public boolean isInCombat(UUID uuid) {
        return combatTime.containsKey(uuid);
    }

    public int getRemainingSeconds(UUID uuid) {
        if (!isInCombat(uuid)) return 0;
        int duration = plugin.getConfig().getInt("combat-duration", 15);
        long elapsed = (System.currentTimeMillis() - combatTime.get(uuid)) / 1000;
        return (int) Math.max(0, duration - elapsed);
    }

    public int getCombatCount() {
        return combatTime.size();
    }

    public void cleanup() {
        for (BukkitTask task : combatTasks.values()) {
            task.cancel();
        }
        combatTasks.clear();
        combatTime.clear();
    }
}
