package com.combatborder.managers;

import com.combatborder.CombatBorder;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class WallManager {

    private final CombatBorder plugin;
    // Map of player UUID -> list of fake block locations shown to them
    private final Map<UUID, Set<Location>> playerWalls = new HashMap<>();
    // Map of player UUID -> runnable updating their wall
    private final Map<UUID, BukkitRunnable> wallTasks = new HashMap<>();

    private static final int WALL_DISTANCE = 3; // blocks ahead of player
    private static final int WALL_WIDTH = 7;
    private static final int CHECK_RADIUS = 5;

    public WallManager(CombatBorder plugin) {
        this.plugin = plugin;
    }

    public void showWallForPlayer(Player player, Location borderLocation) {
        int wallHeight = plugin.getConfig().getInt("wall-height", 6);

        // Remove old wall first
        removeWall(player);

        Set<Location> wallBlocks = new HashSet<>();
        World world = borderLocation.getWorld();
        int bx = borderLocation.getBlockX();
        int bz = borderLocation.getBlockZ();
        int by = borderLocation.getBlockY();

        // Determine wall direction based on player position
        Location playerLoc = player.getLocation();
        double dx = borderLocation.getX() - playerLoc.getX();
        double dz = borderLocation.getZ() - playerLoc.getZ();

        boolean wallAlongZ = Math.abs(dx) > Math.abs(dz);

        for (int i = -WALL_WIDTH / 2; i <= WALL_WIDTH / 2; i++) {
            for (int y = 0; y < wallHeight; y++) {
                Location wallLoc;
                if (wallAlongZ) {
                    wallLoc = new Location(world, bx, by + y, bz + i);
                } else {
                    wallLoc = new Location(world, bx + i, by + y, bz);
                }

                Block block = wallLoc.getBlock();
                if (block.getType() == Material.AIR) {
                    wallBlocks.add(wallLoc);
                    player.sendBlockChange(wallLoc, Material.GLASS.createBlockData());
                }
            }
        }

        playerWalls.put(player.getUniqueId(), wallBlocks);
    }

    public void removeWall(Player player) {
        UUID uuid = player.getUniqueId();

        if (wallTasks.containsKey(uuid)) {
            wallTasks.get(uuid).cancel();
            wallTasks.remove(uuid);
        }

        if (playerWalls.containsKey(uuid)) {
            for (Location loc : playerWalls.get(uuid)) {
                // Restore original block to player
                player.sendBlockChange(loc, loc.getBlock().getBlockData());
            }
            playerWalls.remove(uuid);
        }
    }

    public void removeAllWalls() {
        for (UUID uuid : new HashSet<>(playerWalls.keySet())) {
            Player p = plugin.getServer().getPlayer(uuid);
            if (p != null) removeWall(p);
            else playerWalls.remove(uuid);
        }
    }

    public boolean hasWall(UUID uuid) {
        return playerWalls.containsKey(uuid);
    }

    public int getWallCount() {
        return playerWalls.size();
    }

    /**
     * Update the wall position as player moves near the border.
     * Called every tick from MoveListener.
     */
    public void updateWall(Player player, Location borderLoc) {
        removeWall(player);
        showWallForPlayer(player, borderLoc);
    }
}
