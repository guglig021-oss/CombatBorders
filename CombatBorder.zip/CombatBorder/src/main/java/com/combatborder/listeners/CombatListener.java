package com.combatborder.listeners;

import com.combatborder.CombatBorder;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class CombatListener implements Listener {

    private final CombatBorder plugin;

    public CombatListener(CombatBorder plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;

        Player attacker = null;
        if (event.getDamager() instanceof Player) {
            attacker = (Player) event.getDamager();
        } else if (event.getDamager() instanceof Projectile proj) {
            if (proj.getShooter() instanceof Player) {
                attacker = (Player) proj.getShooter();
            }
        }

        if (attacker == null || attacker.equals(victim)) return;

        plugin.getCombatManager().tag(attacker);
        plugin.getCombatManager().tag(victim);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getCombatManager().untag(event.getPlayer().getUniqueId());
    }
}
