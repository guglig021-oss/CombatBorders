package com.combatborder.listeners;

import com.combatborder.CombatBorder;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.util.Vector;

public class MoveListener implements Listener {

    private final CombatBorder plugin;
    private static final int WALL_SHOW_DISTANCE = 5;

    public MoveListener(CombatBorder plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        if (!plugin.getCombatManager().isInCombat(player.getUniqueId())) {
            // Remove wall if they somehow still have one
            if (plugin.getWallManager().hasWall(player.getUniqueId())) {
                plugin.getWallManager().removeWall(player);
            }
            return;
        }

        if (player.hasPermission("combatborder.bypass")) return;

        Location to = event.getTo();
        if (to == null) return;

        // Check if the destination is a safe zone
        if (plugin.getZoneManager().isSafeZone(to)) {
            // BLOCK the movement - push player back
            event.setCancelled(true);

            // Push player slightly back away from the border
            Location from = event.getFrom();
            Vector pushBack = from.toVector().subtract(to.toVector()).normalize().multiply(0.2);
            player.setVelocity(pushBack);

            // Show the glass wall at the border
            plugin.getWallManager().showWallForPlayer(player, to);

            // Send blocked message
            int remaining = plugin.getCombatManager().getRemainingSeconds(player.getUniqueId());
            String msg = plugin.getConfig().getString("blocked-message",
                "&c&l⚔ You cannot enter a safe zone while in combat! &e(%time%s remaining)");
            msg = msg.replace("%time%", String.valueOf(remaining));

            // Only send message every 2 seconds to avoid spam
            long now = System.currentTimeMillis();
            Long lastMsg = lastMessageTime.get(player.getUniqueId());
            if (lastMsg == null || now - lastMsg > 2000) {
                player.sendMessage(CombatBorder.colorize(msg));
                lastMessageTime.put(player.getUniqueId(), now);
            }
            return;
        }

        // Check if near a safe zone border - show preview wall
        Location borderLoc = plugin.getZoneManager().getNearestBorder(to, WALL_SHOW_DISTANCE);
        if (borderLoc != null) {
            plugin.getWallManager().updateWall(player, borderLoc);
        } else {
            // Not near border - remove wall if showing
            if (plugin.getWallManager().hasWall(player.getUniqueId())) {
                plugin.getWallManager().removeWall(player);
            }
        }
    }

    // Simple cooldown map to avoid message spam
    private final java.util.Map<java.util.UUID, Long> lastMessageTime = new java.util.HashMap<>();
}
