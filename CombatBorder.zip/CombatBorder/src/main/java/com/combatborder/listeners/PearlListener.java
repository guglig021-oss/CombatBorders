package com.combatborder.listeners;

import com.combatborder.CombatBorder;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;

public class PearlListener implements Listener {

    private final CombatBorder plugin;
    private static final int PEARL_CHECK_RADIUS = 20;

    public PearlListener(CombatBorder plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPearlThrow(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof EnderPearl pearl)) return;
        if (!(pearl.getShooter() instanceof Player player)) return;

        if (!plugin.getCombatManager().isInCombat(player.getUniqueId())) return;
        if (player.hasPermission("combatborder.bypass")) return;

        // Check if there's a safe zone within pearl range
        Location borderLoc = plugin.getZoneManager().getNearestBorder(player.getLocation(), PEARL_CHECK_RADIUS);
        if (borderLoc != null) {
            // Cancel the pearl throw
            event.setCancelled(true);

            // Refund the pearl
            player.getInventory().addItem(new ItemStack(Material.ENDER_PEARL, 1));

            String msg = plugin.getConfig().getString("pearl-blocked-message",
                "&c&l⚔ You cannot use Ender Pearls near safe zones while in combat!");
            player.sendMessage(CombatBorder.colorize(msg));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPearlLand(PlayerTeleportEvent event) {
        if (event.getCause() != PlayerTeleportEvent.TeleportCause.ENDER_PEARL) return;

        Player player = event.getPlayer();
        if (!plugin.getCombatManager().isInCombat(player.getUniqueId())) return;
        if (player.hasPermission("combatborder.bypass")) return;

        Location destination = event.getTo();
        if (destination == null) return;

        // Block pearl teleport into safe zone
        if (plugin.getZoneManager().isSafeZone(destination)) {
            event.setCancelled(true);

            // Refund pearl
            player.getInventory().addItem(new ItemStack(Material.ENDER_PEARL, 1));

            String msg = plugin.getConfig().getString("pearl-blocked-message",
                "&c&l⚔ You cannot use Ender Pearls near safe zones while in combat!");
            player.sendMessage(CombatBorder.colorize(msg));
        }
    }
}
